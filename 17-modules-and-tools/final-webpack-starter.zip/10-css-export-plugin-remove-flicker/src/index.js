import './css/style.css';
import message from './message.js';

console.log(message.text);

const hello = () => console.log('Hello');