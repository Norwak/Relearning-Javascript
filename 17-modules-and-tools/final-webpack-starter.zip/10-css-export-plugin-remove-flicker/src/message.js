const message = {
  id: 1,
  text: 'Hello World'
}

export default message;